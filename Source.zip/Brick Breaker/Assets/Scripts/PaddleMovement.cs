using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaddleMovement : MonoBehaviour
{
    private Rigidbody2D player;

    [SerializeField]
    private float movementForce;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        if(Input.GetKey(KeyCode.D))
        {
            player.AddForce(new Vector2(movementForce, 0));
        }

        if (Input.GetKey(KeyCode.A))
        {
            player.AddForce(new Vector2(-movementForce, 0));
        }

        if (Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.A))
        {
            player.velocity = Vector2.zero;
        }
    }
}
