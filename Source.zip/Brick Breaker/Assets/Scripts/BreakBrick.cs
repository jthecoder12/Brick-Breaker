using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BreakBrick : MonoBehaviour
{
    private int count;

    [SerializeField]
    private GameObject endScreen;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Brick"))
        {
            Destroy(collision.gameObject);
            count++;
        }
    }

    private void Update()
    {
        if(count >= 32)
        {
            endScreen.SetActive(true);
        }
    }
}
